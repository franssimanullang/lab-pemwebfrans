import pg from "pg";
import dotenv from "dotenv";

dotenv.config();

const { Pool } = pg;

const pool = new Pool({
  connectionString: process.env.DATABASE_CONNECTION_STRING,
  ssl: { rejectUnauthorized: false },
});

export default pool;
